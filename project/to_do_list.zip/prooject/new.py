from tkinter import *
import tkinter as tk
import sqlite3
from tkinter import messagebox,filedialog

class todoapp:
    def __init__(self,root):
        self.root=root
        self.root.title("TO-DO list")
        self.root.configure(bg="black")
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_columnconfigure(1, weight=1)
        self.root.grid_columnconfigure(2, weight=1)
        self.root.grid_columnconfigure(3, weight=1)
        self.root.grid_columnconfigure(4, weight=1)
        self.root.grid_rowconfigure(2, weight=1)
        self.photo=tk.PhotoImage(file="lo.png")
        x = root.winfo_screenwidth()
        y = root.winfo_screenheight()

        self.imagelabel=tk.Label(image=self.photo)
        self.imagelabel.place(x=int(x/2) - 100, y=5)
        self.imagelabel.config(highlightbackground="white", highlightcolor="white", highlightthickness=2)

        #self.frame1=tk.Frame(self.root)
        #self.frame1.grid(row=2,column=1)

        self.frame=tk.Frame(self.root,bg="black")
        self.frame.grid(row=2,column=0)
        self.mainlabel=tk.Label(self.frame,text="Create Todo",bg="black",fg="white",font=("CALIBARI",24,"bold"),justify="center")
        self.mainlabel.grid(row=1,column=1)
        self.idlabel=tk.Label(self.frame,text="ID",fg="white",bg="black",font=("CALIBRI",24),padx=5)
        self.idlabel.grid(row=2,column=0)
        self.identry=tk.Entry(self.frame,width=35,relief="groove")
        self.identry.grid(row=2,column=1)
        self.titlelabel=tk.Label(self.frame,text="Title",bg="black",fg="white",font=("CALIBRI",24),padx=5)
        self.titlelabel.grid(row=4,column=0)
        self.titleentry=tk.Entry(self.frame,width=35,relief="groove")
        self.titleentry.grid(row=4,column=1)
        #self.timinglabel=tk.Label(self.frame,text="Time",fg="black",font=("CALIBRI",24),bg="white",padx=5)
        #self.timinglabel.grid(row=5,column=0)
        #self.timingentry=tk.Entry(self.frame,width=35,relief="groove")
        #self.timingentry.grid(row=5,column=1)
        self.text=tk.Label(self.frame,bg="black",font=("CALIBRI",18),text="NOTE    -ID and title input is needed to create a todo\n-ID input alone is needed to delete todo and get todo\n-Both fields are needed to update a todo",fg="white")
        self.text.grid(row=6,column=1)
        self.create_button = tk.Button(self.frame, text="Create TODO",bg="navy",fg="white",font=("CALIBRI",15),width=20,command=self.createtodo)
        self.create_button.grid(row=7, column=0, pady=5)
        self.listall = tk.Button(self.frame, text="List all TODO",command=self.listall,bg="black",fg="white",font=("CALIBRI",15),width=20)
        self.listall.grid(row=7, column=1,  pady=5)
        self.update_button = tk.Button(self.frame, text="Update TODO",command=self.update_todo,bg="skyblue",fg="black",font=("CALIBRI",15),width=20)
        self.update_button.grid(row=8, column=0,  pady=5)
        self.Delete_button = tk.Button(self.frame,command=self.delete_todo, text="Delete TODO",bg="red",fg="white",font=("CALIBRI",15),width=20)
        self.Delete_button.grid(row=8, column=1, pady=5)
        self.comp_button = tk.Button(self.frame,command=self.markascompleted_todo, text="Mark As Completed",bg="green",fg="white",font=("CALIBRI",15),width=20)
        self.comp_button.grid(row=9, column=0, pady=5)
        self.get_button=tk.Button(self.frame,command=self.gettodo,text="Get todo",bg="blue",fg="white",font=("CALIBRI",15),width=20)
        self.get_button.grid(row=9, column=1, pady=5)

        self.conn = sqlite3.connect("todos.db")
        self.cursor = self.conn.cursor()



    def createtodo (self):

        title=self.titleentry.get()
        if  len(str(title))!=0:
            self.conn = sqlite3.connect("todos.db")
            self.cursor = self.conn.cursor()
            #self.cursor.execute('''CREATE TABLE  TODOList (ID	INTEGER,Title	TEXT,Comp/not-comp)''')
            self.conn.commit()
            status="Not completed"
            self.cursor.execute ("INSERT INTO TODOList (TITLE,status) VALUES (?, ?)",(title,status))
            self.conn.commit()
            self.titleentry.delete(0,tk.END)
        else:
            messagebox.showwarning("Warning", " Title should not be empty")
    def update_todo(self):
        title=self.titleentry.get()
        idd=self.identry.get()
        if len(str(idd))!=0 and len(str(title))!=0:
            self.cursor.execute("UPDATE TODOList SET Title=? WHERE ID=?",(title,idd))
            self.conn.commit()
            self.titleentry.delete(0,tk.END)
            self.identry.delete(0,tk.END)
        else:
            messagebox.showwarning("Warning","ID or title should not be empty")
    def delete_todo(self):
        idd=self.identry.get()
        if len(str(idd))!=0:
            self.cursor.execute("DELETE FROM TODOList WHERE ID=?", (idd,))
            self.conn.commit()
            self.identry.delete(0,tk.END)
        else:
            messagebox.showwarning("Warning","ID field should not be empty")
    def markascompleted_todo(self):

        idd=self.identry.get()
        status="Completed"
        if len(str(idd))!=0:
            self.cursor.execute("UPDATE TODOList SET status=? WHERE ID=?",(status,idd))
            self.conn.commit()
            self.identry.delete(0,tk.END)
        else:
            messagebox.showwarning("Warning","ID field should not be empty")
    def listall(self):

        x = self.root.winfo_screenwidth()
        y = self.root.winfo_screenheight()

        self.all_todo_frame = tk.Frame(self.root, width=int(x/2), height=y, bg="white")
        self.all_todo_frame.place(x=int(x/3)+400, y=200)
        self.labels=tk.Label(self.all_todo_frame,text="All TODOS",font=("CALIBRI",24,"bold"),fg="black",bg="white")
        self.labels.place(x=0,y=0)
        self.list_box= tk.Listbox(self.all_todo_frame, width=int(x/2), height=30, bg="white", fg="black", font=('normal', 15))
        self.list_box.place(x=10, y=50)


        self.conn = sqlite3.connect("todos.db")
        self.cursor = self.conn.cursor()
        a=self.cursor.execute("select * from TODOList")
        for row in a:
            data=f"{row[0]} |{row[1]} | {row[2]}"
            self.list_box.insert(self.list_box.size()+2,data)
        self.conn.commit()
    def gettodo(self):
        idd=self.identry.get()
        if len(str(idd))!=0:
            x = self.root.winfo_screenwidth()
            y = self.root.winfo_screenheight()
            self.all_todo_frame = tk.Frame(self.root, width=int(x/2), height=y, bg="white")
            self.all_todo_frame.place(x=int(x/3)+400, y=200)
            self.labels=tk.Label(self.all_todo_frame,text="Required TODO",font=("CALIBRI",24,"bold"),fg="black",bg="white")
            self.labels.place(x=0,y=0)
            self.list_box= tk.Listbox(self.all_todo_frame, width=int(x/2), height=30, bg="white", fg="black", font=('normal', 15))
            self.list_box.place(x=10, y=50)
            self.conn = sqlite3.connect("todos.db")
            self.cursor = self.conn.cursor()
            a=self.cursor.execute("select * from TODOList Where ID=?",(idd))
            for row in a:
                data=f"{row[0]} |{row[1]} | {row[2]}"
            self.list_box.insert(self.list_box.size()+2,data)
            self.conn.commit()
        else:
            messagebox.showwarning("Warning","ID field should not be empty")

def main():
    root = tk.Tk()
    app = todoapp(root)

    root.mainloop()

if __name__ == "__main__":
    main()
