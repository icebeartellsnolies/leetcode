from tkinter import *
import tkinter.messagebox as tmsg
from PIL import Image, ImageTk


class User(Tk):

    def __init__(self):
        super().__init__()
        # interface
        color="white"
        self.geometry("670x680")
        self.configure(bg="white")
        self.title("USER INFO")

        # frame
        self.frm = Frame(self, relief="sunken", bg=color)
        self.frm.pack(side="top", fill="x", padx=10, pady=5, ipady=50)

        # name label
        self.name_label = Label(
            self.frm, text="Enter your name : ", font=("Helvetica 10 bold"), bg=color
        )
        self.name_label.grid(row=0, column=0, padx=10, ipady=30)

        # entry box for name
        self.name = StringVar()
        self.e1 = Entry(self.frm, textvariable=self.name, relief="sunken", borderwidth=2)
        self.e1.grid(row=0, column=1, pady=10, ipadx=25, ipady=10)

        # age label
        self.age_label = Label(
            self.frm, text="Choose your age : ", font=("Helvetica 10 bold"), bg=color
        )
        self.age_label.grid(row=3, column=0, pady=15)

        # spin box for age
        self.spin_box = Spinbox(self.frm, from_=0, to=100, width=2, borderwidth=2)
        self.spin_box.grid(row=3, column=1, pady=15, ipadx=25, ipady=14)

        # gender label
        self.gender_label = Label(
            self.frm, text="Choose your gender : ", font=("Helvetica 10 bold"), bg=color
        )
        self.gender_label.grid(row=5, column=0, pady=10)
        self.gender = StringVar()

        # radio button for gender
        self.choice1 = Radiobutton(self.frm, text="Male", font=("Helvetica 10 bold"), borderwidth=2, bg=color, variable=self.gender, value="Male")
        self.choice1.grid(row=5, column=1, ipadx=10, ipady=2)
        self.choice2 = Radiobutton(self.frm, text="Female", font=("Helvetica 10 bold"), borderwidth=2, bg=color, variable=self.gender, value="Female")
        self.choice2.grid(row=6, column=1, ipadx=10, ipady=2)

        # height label
        self.height_label = Label(
            self.frm, text="Choose your height (ft,inches) : ", font=("Helvetica 10 bold"), bg=color
        )
        self.height_label.grid(row=9, column=0, pady=15)

        # spin box for height in ft
        self.spin_box1 = Spinbox(self.frm, from_=1, to=10, borderwidth=2)
        self.spin_box1.grid(row=9, column=1, pady=10, ipadx=25, ipady=14, padx=5)

        # spin box for height in inchs
        inch_values = [str(i / 10) for i in range(0, 50)]
        self.spin_box2 = Spinbox(self.frm, values=inch_values, borderwidth=2)
        self.spin_box2.grid(row=9, column=2, pady=6, ipadx=25, ipady=14, padx=5)

        # weight label
        self.weight_label = Label(
            self.frm, text="Enter your weight (kg) : ", font=("Helvetica 10 bold"), bg=color
        )
        self.weight_label.grid(row=10, column=0, padx=10, pady=20)

        # entry box for weight label
        self.weight = DoubleVar()
        self.e2 = Entry(self.frm, textvariable=self.weight, relief="sunken", borderwidth=2)
        self.e2.grid(row=10, column=1, pady=25, ipadx=20, ipady=10, padx=20)

        # Button to submit and validate age consent
        self.submit_button = Button(self, text="Submit", font=("Helvetica 10 bold"), command=self.validate_age_consent, bg="#4CAF50", relief="raised")
        self.submit_button.pack(side="bottom", anchor="se", ipady=10, ipadx=15, padx=20, pady=5)

        # activity level label
        self.activity = Label(
            self.frm, text="Choose your activity level : ", font=("Helvetica 10 bold"), bg=color
        )
        self.activity.grid(row=11, column=0, padx=10, pady=10)

        # radio button for activity level
        self.activity_level = StringVar()
        self.c1 = Radiobutton(self.frm, text="Sedentary", font=("Helvetica 10 bold"), bg=color, value="Sedentary", variable=self.activity_level, borderwidth=2)
        self.c1.grid(row=11, column=1, ipadx=10, ipady=2)
        self.c2 = Radiobutton(self.frm, text="Lightly active", font=("Helvetica 10 bold"), bg=color, value="Lightly active", variable=self.activity_level, borderwidth=2)
        self.c2.grid(row=12, column=1, ipadx=10, ipady=2)
        self.c3 = Radiobutton(self.frm, text="Moderately Active", font=("Helvetica 10 bold"), bg=color, value="Moderately Active", variable=self.activity_level, borderwidth=2)
        self.c3.grid(row=13, column=1, ipadx=10, ipady=2)
        self.c4 = Radiobutton(self.frm, text="Very Active", font=("Helvetica 10 bold"), bg=color, value="Very Active", variable=self.activity_level, borderwidth=2)
        self.c4.grid(row=14, column=1, ipadx=10, ipady=2)

    def validate_age_consent(self):
        age = int(self.spin_box.get())
        height_ft = int(self.spin_box1.get())
        height_inch = float(self.spin_box2.get())
        weight = int(self.weight.get())
        activity = self.activity_level.get()
        if age < 18:
            tmsg.showinfo("Consent", "Need your parents' consent!")
        else:
            height_m = (height_ft * 0.3048) + (height_inch * 0.0254)
            bmi = weight / (height_m ** 2)
            self.destroy()
            self.show_bmi_window(bmi, activity)

    # creates new window
    def show_bmi_window(self, bmi, activity):
        new_window = BMI(bmi, activity)
        new_window.mainloop()

# class for BMI WINDOW
class BMI(Toplevel):

    def __init__(self, bmi, activity):
        super().__init__()
        # interface
        self.bmi = bmi
        color = "white"
        self.geometry("720x680")
        self.configure(bg=color)
        self.title("USER INFO")
        # image path for logo
        self.image_path = r"logo.jpeg"
        self.load_image(self.image_path)
        # Label for app name
        self.app_name_label = Label(self, text="Balanced Bite", font=("Helvetica 19 bold"), bg=color)
        self.app_name_label.pack(pady=5)
        # label for Summary
        self.L1 = Label(self, text="Your Summary", font=("Helvetica 19 bold"), bg=color)
        self.L1.pack(pady=3)
        self.scale = Scale(self, from_=0, to=100, orient='horizontal', label="Body Mass Index (BMI)", resolution=2, length=400, width=25, activebackground="lightgreen", bg='light blue', fg='black', font=("Helvetica,15,bold"))
        self.scale.pack(pady=30)
        self.scale.set(self.bmi)
        # image path for 2nd image
        self.image_path1 = r"diet.jpg"
        self.load_image1(self.image_path1)

        # showing label according to BMI
        if self.bmi < 18.5:
            self.L3 = Label(self, text='You are underweight!', font=("Helvetica 12 bold"), bg=color, fg="green")
            self.L3.pack(pady=3)
            self.L4 = Label(self, text='(Focus on increasing muscle mass and strength.', fg="red", font=("Helvetica 12 bold"), bg=color)
            self.L4.pack(pady=3)
            self.L5 = Label(self, text='Ensure a balanced diet to gain healthy weight.)', fg="red", font=("Helvetica 12 bold"), bg=color)
            self.L5.pack(pady=3)
        elif self.bmi >= 18.5 and self.bmi <= 24.9:
            self.L3 = Label(self, text='You are Healthy!', fg="green", font=("Helvetica 12 bold"), bg=color)
            self.L3.pack(pady=3)
            self.L4 = Label(self, text='Maintain a balanced diet to support overall health and vitality!', fg="red", font=("Helvetica 12 bold"), bg=color)
            self.L4.pack(pady=3)
        elif self.bmi > 24.9 and self.bmi <= 29.9:
            self.L3 = Label(self, text='You are overweight!', fg="green", font=("Helvetica 12 bold"), bg=color)
            self.L3.pack(pady=3)
            self.L4 = Label(self, text='(Focus on balanced meals and portion control.', fg="red", font=("Helvetica 12 bold"), bg=color)
            self.L4.pack(pady=3)
            self.L5 = Label(self, text='Increase physical activity for better health and weight management.)', fg="red", font=("Helvetica 12 bold"), bg=color)
            self.L5.pack(pady=3)
        elif self.bmi >= 30:
            self.L3 = Label(self, text='You are obese!', fg="green", font=("Helvetica 12 bold"), bg=color)
            self.L3.pack(pady=3)
            self.L4 = Label(self, text='(Focus on balanced, nutrient-dense meals and portion control.', fg="red", font=("Helvetica 12 bold"), bg=color)
            self.L4.pack(pady=3)
            self.L5 = Label(self, text='Increase physical activity and consider seeking guidance for sustainable weight loss.)', fg="red", font=("Helvetica 12 bold"), bg=color)
            self.L5.pack(pady=3)

        # Button to Continue
        self.continue_button = Button(self, text="Continue", font=("Helvetica 12 bold"), command=self.continue_to_main, bg="#4CAF50", relief="raised")
        self.continue_button.pack(pady=20)

    # function to load image
    def load_image(self, path):
        self.img = Image.open(path)
        self.img = self.img.resize((70, 70), Image.Resampling.LANCZOS)
        self.img = ImageTk.PhotoImage(self.img)
        self.panel = Label(self, image=self.img)
        self.panel.pack(pady=20)

    # function to load second image
    def load_image1(self, path):
        self.img1 = Image.open(path)
        self.img1 = self.img1.resize((150, 150), Image.Resampling.LANCZOS)
        self.img1 = ImageTk.PhotoImage(self.img1)
        self.panel1 = Label(self, image=self.img1)
        self.panel1.pack(pady=10)

    def continue_to_main(self):
        self.destroy()
        main_window = MainWindow(self.bmi)
        main_window.mainloop()


class MainWindow(Toplevel):
    def __init__(self, bmi):
        super().__init__()
        self.geometry("720x680")
        self.configure(bg="white")
        self.title("Diet Plan Selection")
        # Adding Labels, Images, and other GUI elements for the Main Window
        '''self.label = Label(self, text="Welcome to the Diet Plan Selection", font=("Helvetica 19 bold"), bg="white")
        self.label.pack(pady=5)'''
        self.bmi = bmi
        self.title("Diet Planner")
        self.geometry("800x600")  # Adjusted size for better layout

        # Create a main frame for content organization
        self.main_frame = Frame(self, bg="#f5f5f5", padx=3)
        self.main_frame.pack(fill=BOTH, expand=True)

        # Title label with a more motivating or informative message
        self.title_label = Label(
            self.main_frame,
            text="Welcome to your personalized diet plan!",
            font=("Arial", 15, "bold"),
            bg="#f5f5f5",
        )
        self.title_label.pack(pady=10)

        # Dietary preference selection frame
        self.preference_frame = Frame(self.main_frame, bg="#f5f5f5")
        self.preference_frame.pack()

        self.preference_var = StringVar(
            self.preference_frame)  # Single variable for dietary preferences
        self.preference_var.set(None)  # Initial state

        # Dietary preference checkboxes with improved styling
        self.preferences = [
            ("Vegetarian", "veg"),
            ("Non-Vegetarian", "non-veg"),
            ("Gluten-Free", "gluten_free"),
            ("No Restrictions", "none"),
        ]

        for text, value in self.preferences:
            checkbox = Checkbutton(
                self.preference_frame,
                text=text,
                variable=self.preference_var,
                onvalue=value,
                offvalue="",
                bg="#f5f5f5",  # Set background for consistency
                font=("Arial", 13),
            )
            checkbox.pack(anchor=W)  # Align checkboxes to the left

        # Button to display diet plan
        self.show_plan_button = Button(
            self.main_frame,
            text="Show Diet Plan",
            command=self.show_diet_plan,
            font=("Arial", 13, "bold"),
            padx=20,
            pady=4,
            bg="#4CAF50",
            fg="white",
        )
        self.show_plan_button.pack(pady=5)

        # New button to see recipes for plans
        self.recipes_button = Button(
            self.main_frame,
            text="See Recipes for Plans",
            command=self.show_recipes,
            font=("Arial", 13, "bold"),
            padx=20,
            pady=4,
            bg="#4CAF50",
            fg="white",
        )
        self.recipes_button.pack(pady=5)

        # Diet plan image label with initial text
        self.diet_plan_label = Label(
            self.main_frame,
            text="Select your dietary preference to view a suitable diet plan.",
            font=("Arial", 12),
            bg="#f5f5f5",
        )
        self.diet_plan_label.pack()

    def show_diet_plan(self):
        selected_diet = self.preference_var.get()
        if selected_diet and self.bmi:
            # Weight gain
            if self.bmi < 18.5 and selected_diet == 'veg':
                diet_plan_filename = 'veg_weight_gain_diet_plan.png'
            elif self.bmi < 18.5 and selected_diet == 'non-veg':
                diet_plan_filename = 'non-veg_weight_gain_diet_plan.png'
            elif self.bmi < 18.5 and selected_diet == 'gluten_free':
                diet_plan_filename = 'gluten_free_weight_gain_diet_plan.png'
            elif self.bmi < 18.5 and selected_diet == 'none':
                diet_plan_filename = 'weight_gain_diet_plan.png'
            # Weight maintain normal
            elif 18.5 <= self.bmi <= 24.9 and selected_diet == 'veg':
                diet_plan_filename = 'veg_maintain_fitness_diet_plan.png'
            elif 18.5 <= self.bmi <= 24.9 and selected_diet == 'non-veg':
                diet_plan_filename = 'non-veg_maintain_fitness_diet_plan.png'
            elif 18.5 <= self.bmi <= 24.9 and selected_diet == 'gluten_free':
                diet_plan_filename = 'gluten_free_maintain_fitness_diet_plan.png'
            elif 18.5 <= self.bmi <= 24.9 and selected_diet == 'none':
                diet_plan_filename = 'maintain_fitness_diet_plan.png'
            # Weight loss
            elif (
                    25 <= self.bmi <= 29.9 or self.bmi >= 30) and selected_diet == 'veg':
                diet_plan_filename = 'veg_weight_loss_diet_plan.png'
            elif (
                    25 <= self.bmi <= 29.9 or self.bmi >= 30) and selected_diet == 'non-veg':
                diet_plan_filename = 'non-veg_weight_loss_diet_plan.png'
            elif (
                    25 <= self.bmi <= 29.9 or self.bmi >= 30) and selected_diet == 'gluten_free':
                diet_plan_filename = 'gluten_free_weight_loss_diet_plan.png'
            elif (
                    25 <= self.bmi <= 29.9 or self.bmi >= 30) and selected_diet == 'none':
                diet_plan_filename = 'weight_loss_diet_plan.png'
            else:
                self.diet_plan_label.config(
                    text="Please select a dietary preference to view a diet plan.",
                    image=""
                )

            try:
                self.diet_img = Image.open(diet_plan_filename)
                self.diet_img = self.diet_img.resize((460, 300),
                                                     Image.Resampling.LANCZOS)
                self.diet_img = ImageTk.PhotoImage(self.diet_img)
                self.diet_panel = Label(self, image=self.diet_img)
                self.diet_panel.pack(pady=3)
            except FileNotFoundError:
                self.diet_plan_label.config(
                    text="Diet plan image not found. Please ensure the file exists.",
                    image="",
                )
        else:
            self.diet_plan_label.config(
                text="Please select a dietary preference to view a diet plan.",
                image=""
            )

    def show_recipes(self):
        self.destroy()
        app = Recipes()
        app.mainloop()
        # Add your additional setup for the main window here


class Recipes(Toplevel):
    def __init__(self):
        super().__init__()
        self.color = "white"
        self.win_title = "recipes"
        self.frm = Frame(self)
        self.frm.grid(row=0, column=0, padx=10, pady=10)

        self.image_recipe_paths_b = {
            "b1.jpeg": "br1.jpeg",
            "b2.jpeg": "br2.jpeg",
            "b3.jpeg": "br3.jpeg",
            "b4.jpeg": "br4.jpeg",
            "b5.jpeg": "br5.png",
        }
        self.image_recipe_paths_l = {
            "l1.jpeg": "lr1.jpeg",
            "l2.jpeg": "lr2.jpeg",
            "l3.jpeg": "lr3.jpeg",
            "l4.jpeg": "lr4.jpeg",
            "l5.jpeg": "lr5.jpeg",
        }
        self.image_recipe_paths_d = {
            "d1.jpeg": "dr1.jpeg",
            "d2.jpeg": "dr2.jpeg",
            "d3.jpeg": "dr3.jpeg",
            "d4.jpeg": "dr4.jpeg",
            "d5.jpeg": "dr5.jpeg",
        }
        self.create_widgets()

    def create_widgets(self):
        Label(
            self.frm,
            text="MUNCH ON THE DELICIOUS AND HEALTHY",
            font=("cursive", 16, "italic", "bold"),
            anchor="center",
        ).grid(row=0, column=0, columnspan=5, pady=(20, 10))
        self.add_section("BREAKFAST", 1, self.image_recipe_paths_b)
        self.add_section("LUNCH", 4, self.image_recipe_paths_l)
        self.add_section("DINNER", 7, self.image_recipe_paths_d)

    def add_section(self, title, row_start, dict):
        Label(self.frm, text=title, font=("cursive", 16, "italic",
                                           "bold")).grid(
            row=row_start, column=0
        )
        self.food_imgs(row_start + 1, dict)

    def show_recipe(self, event=None, recipe_image_path=None):
        if recipe_image_path:
            popup = Toplevel()
            popup.title("recipe")
            img = Image.open(recipe_image_path)
            img = img.resize((500, 600))
            photo = ImageTk.PhotoImage(img)
            l = Label(popup, image=photo)
            l.image = photo
            l.grid(row=0, column=0, padx=10, pady=10)
            popup.mainloop()

    def food_imgs(self, start_row, image_recipe_paths):
        photos = []
        for image_path, recipe_path in image_recipe_paths.items():
            image = Image.open(image_path)
            image = image.resize((227, 150))
            photo = ImageTk.PhotoImage(image)
            photos.append((photo, recipe_path))

        r = start_row
        c = 0
        for photo, recipe_path in photos:
            label = Label(self.frm, image=photo)
            label.image = photo  # Keep a reference to the image
            label.grid(row=r, column=c, padx=10, pady=10)
            label.bind(
                "<Button-1>",
                lambda event, rp=recipe_path: self.show_recipe(event, rp),
            )
            c += 1


if __name__ == "__main__":
    root = User()
    root.mainloop()
