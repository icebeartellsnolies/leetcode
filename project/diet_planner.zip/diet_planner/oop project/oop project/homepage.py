import tkinter as tk
from PIL import Image, ImageTk
from user_interface import User

class BalanceBiteApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Balance Bite")
        self.root.geometry("400x600")


        self.logo_img = Image.open("logo.jpeg").resize((150, 150),
                                                       Image.Resampling.LANCZOS)
        self.logo_photo = ImageTk.PhotoImage(self.logo_img)
        self.logo_label = tk.Label(root, image=self.logo_photo)
        self.logo_label.place(relx=0.5, rely=0.2, anchor=tk.CENTER)

        self.app_name = tk.Label(
            root, text="Balance Bite", font=("Helvetica", 30, "bold"), fg="#2ECC71"
        )
        self.app_name.place(relx=0.5, rely=0.4, anchor=tk.CENTER)

        self.description = tk.Label(root, text="Your ultimate companion for balanced nutrition and healthy living.",
            font=("Helvetica", 16), wraplength=300, justify="center", fg="#424242")
        self.description.place(relx=0.5, rely=0.55, anchor=tk.CENTER)

        self.next_button = tk.Button(
            root,
            text="Get Started",
            font=("Helvetica", 16, "bold"),
            bg="#2ECC71",
            fg="white",
            command=self.go_to_next_page,
        )
        self.next_button.place(relx=0.5, rely=0.7, anchor=tk.CENTER)

    def go_to_next_page(self):
        for widget in self.root.winfo_children():
            widget.destroy()
        self.show_next_page()

    def show_next_page(self):
        root.destroy()
        window = User()
        window.mainloop()


if __name__ == "__main__":
    root = tk.Tk()
    app = BalanceBiteApp(root)
    root.mainloop()
